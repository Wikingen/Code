#ifndef GAME_CPP
#define GAME_CPP

#include "Entity.hpp"

class Game
{
public:
    // Default unparameterized constructor
    Game();

    //Parameterized constructor
    Game(Entity players[], Entity enemies[], int num_players, int num_enemies);

    //Loads all entities from a file, the are_players parameters dictates if enteties are loaded to the _all_enemies array or _all_players
    bool loadEnteties(string filename, bool are_players);

    //Loads all items into _all_potions and _all_equipment
    bool loadItems(string filename);

    // Returns the current number of players _num_players
    int getNumPlayers();

    // Returns the current number of enemies _num_enemies
    int getNumEnemies();

    /* Sets the _players array with the provided array of objects.
    The number of objects in the array is specified by the int parameter.
    If the number of objects is greater than 2, only the first two objects are considered.
    The data member _num_players is updated accordingly.*/
    void setPlayersList(Entity arr[], int num_players);

    /*Sets the _enemies array with the provided array of objects.
    The number of objects in the array is specified by the int parameter.
    If the number of objects is greater than 2, only the first two objects are considered.
    The data member _num_enemies is updated accordingly.
     */
    void setEnemiesList(Entity arr[], int num_enemies);

    // Replaces a player object at the given index in the _players array.
    bool setPlayer(int index, Entity new_player);


    // Returns an object from the _players array based on the index
    Entity getPlayer(int index);

    // Returns an object from the _all_players array based on the provided name
    Entity getPlayerFromAll(string name);

    //Returns a potion from _all_potions
    Potion getPotion(string name);
    //Returns a equipment from _all_equipment
    Equipment getEquipment(string name);

    // Replaces an enemy object at the given index in the _enemies array.
    bool setEnemy(int index, Entity new_enemy);

    // Returns an object from the _enemies array based on the provided name
    Entity getEnemy(string name);

    // Returns the index of the player object in the _players array based on the provided name.
    int findPlayer(string name);

    // Returns the index of the enemy object in the _enemies array based on the provided name.
    int findEnemy(string name);

    int findPotion(string name);

    // Prints stats of all the players and enemies.
    void printAllStats();
    
    void printAllPotions();
    void printAllEquipment();

    //Picks starting character
    Entity playerPick();

    // Prints options, MOve, Swap/Drop, Potion,stats or quir. returns valid option 1-5
    int mainMenu();

private:
    Entity _players[2];
    Entity _enemies[2];
    int _num_players;
    int _num_enemies;

    static const int _MAX_PLAYERS = 10;
    static const int _MAX_ENEMIES = 10;
    Entity _all_players[_MAX_PLAYERS];
    Entity _all_enemies[_MAX_ENEMIES];

    static const int _MAX_POTIONS = 10;
    Potion _all_potions[_MAX_POTIONS];
    static const int _MAX_EQUIPMENT = 20;
    Equipment _all_equipment[_MAX_EQUIPMENT];
    

};
#endif