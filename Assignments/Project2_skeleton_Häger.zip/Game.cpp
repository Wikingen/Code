#include "Game.hpp"
#include "Functions.hpp"
#include "Items.hpp"
#include "utils.hpp"

Game::Game()
{
    _num_players = 0;
    _num_enemies = 0;
}

// Parameterized constructor
Game::Game(Entity players[], Entity enemies[], int num_players, int num_enemies)
{

    // cout << "We pass num_players with the value " << num_players <<endl;

    // Makes sure there is max 2 enemies, and sets it to zero if negative number is given
    if (num_players > 2)
    {
        _num_players = 2;
    }
    else if (num_players < 0)
    {
        _num_players = 0;
    }
    else
    {
        _num_players = num_players;
    }

    for (int i = 0; i < _num_players; i++)
    {
        _players[i] = players[i];
    }

    if (num_enemies > 2)
    {
        _num_enemies = 2;
    }
    else if (num_enemies < 0)
    {
        _num_enemies = 0;
    }
    else
    {
        _num_enemies = num_enemies;
    }

    for (int i = 0; i < _num_enemies; i++)
    {
        _enemies[i] = enemies[i];
    }
}

// Loads characters and enemies into the _all_players and _all_enemies arrays
bool Game::loadEnteties(string filename, bool are_players)
{
    ifstream in_file(filename);
    if (in_file.fail())
    {
        return false;
    }

    string name;
    // char type; //'p' - playeable character, 'I' - Island enemy, 'E' - Epic enemy
    double hp;
    double stamina;
    double defense;
    char condition; // H,D,P
    bool advantage; // Deciding weather you have an advanteage to start first
    // char el_weak; //Elemental weakness
    int gold;
    Potion new_potion;       // Will work as temporary potion to add to new entity
    Equipment new_equipment; // Will work as temporary equipment to add to new entities

    string splitted_line2[2]; // will contain the names of equiped items
    string potion_name;
    string equipment_name;

    int items[2];

    string line2;             // Here we take in the whole line of elements 9
    string splitted_line[15]; // array with all elements from one input line. Size should be 12, but we overshoot with 15
    int num_elements;         // number of elements in splitted string
    int curr_index = 0;       // Keeps track of where in the character array we are
    Entity new_player;        // Temporary entity object to fill entity lists wirth

    string line;            // Input lines from textfile
    getline(in_file, line); // Get rid of first line since it is a title-line

    while (getline(in_file, line) && curr_index < _MAX_PLAYERS)
    {
        num_elements = split(line, '|', splitted_line, 15);

        if (num_elements != 12) // skip invalid rows
        {
            cout << "DEBUG line " << curr_index << " Has " << num_elements << " and not 12" << endl;
            continue;
        }

        // NOTE THE FOLLOWING VALIDATION IS REPETETIVE SINCE IT IS ALREADY CHECKED IN SETTERS

        name = splitted_line[0]; // If its a valid double we add it otherwise it is set to 0
        // cout << "DEBUG Gave the name: " << name << " on iteration " << curr_index  << endl;

        // type = splitted_line[1][0];

        if (isDouble(splitted_line[2]))
        {
            hp = stod(splitted_line[2]);
        }
        else
        {
            hp = 0;
        }

        // cout << "DEBUG Gave the hp: " << hp << " on iteration " << curr_index << endl;

        if (isDouble(splitted_line[3]))
        {
            stamina = stod(splitted_line[3]);
        }
        else
        {
            stamina = 0;
        }

        // cout << "DEBUG Gave the stamina: " << stamina << " on iteration " << curr_index << endl;

        if (isDouble(splitted_line[4]))
        {
            defense = stod(splitted_line[4]);
        }
        else
        {
            defense = 0;
        }

        // cout << "DEBUG Gave the defense: " << defense << " on iteration " << curr_index << endl;

        if (splitted_line[5][0] == 'H' || splitted_line[5][0] == 'D' || splitted_line[5][0] == 'P') // if its a valid condition it is set, else it is 'H'
        {
            condition = splitted_line[5][0]; // add index 0 to make it a char
        }
        else
        {
            condition = 'H';
        }

        // cout << "DEBUG Gave the condition: '" << condition << "' on iteration " << curr_index << endl;

        if (splitted_line[6] == "true")
        {
            advantage = true;
        }
        else
        {
            advantage = false;
        }

        // cout << "DEBUG Set the advantage to: " << advantage << " on iteration " << curr_index << endl;

        // sets elemtal weaknesses, default is fire
        /*    if (splitted_line[7][0] == 'W' || splitted_line[7][0] == 'F' || splitted_line[7][0] == 'A' || splitted_line[7][0] == 'A') // if its a valid element it updates
           {
               el_weak = splitted_line[7][0]; // add index 0 to make it a char
           }
           else
           {
               el_weak = 'F';
           } */

        // Sets gold
        if (isInteger(splitted_line[8])) // if it is a valid int it will be added otherwise it is set to 0
        {
            gold = stoi(splitted_line[8]);
        }
        else
        {
            gold = 0;
        }

        line2 = splitted_line[9];

        split(line2, ',', splitted_line2, 2);
        // cout << "Line2:  " << line2 << endl;
        // cout << "Splitted line:  " << splitted_line2[0] << ",   " << splitted_line2[1] << endl;
        potion_name = splitted_line2[0];
        // cout << "Potion name " << potion_name << endl;
        new_potion = getPotion(potion_name);
        // cout << "Name of new potion  " << new_potion.name << endl;
        new_potion.quantity = 1; // Set initial quatnity to 1

        equipment_name = splitted_line2[1];
        // cout << "SPlitted line[1]" << splitted_line2[1] << endl;
        new_equipment = getEquipment(equipment_name);

        // cout << "DEBUG Set the gold value to: " << gold << " on iteration " << curr_index << endl;

        // cout << "DEBUG Is_player is set to: " << are_players << " on iteration " << curr_index << endl;

        if (are_players)
        {
            _all_players[curr_index].setName(name);
            _all_players[curr_index].setHP(hp);
            _all_players[curr_index].setGold(gold);
            _all_players[curr_index].setStamina(stamina);
            _all_players[curr_index].setDefense(defense);
            _all_players[curr_index].setCondition(condition);
            _all_players[curr_index].setAdvantage(advantage);
            _all_players[curr_index].setItems(items);
            _all_players[curr_index].setPotion(0, new_potion); // saves the loaded potion in spot 1
            _all_players[curr_index].setNumPotion(1);
            _all_players[curr_index].setEquipment(0, new_equipment);
            _all_players[curr_index].setNumEquipment(1);

            /*          _players[curr_index].setPotions(potions);
                        _players[curr_index].setEquipped(equipped);
                        _players[curr_index].setInventory(inventory); */
            // cout << name  << " was successfully initiated" << endl;

            _num_players = curr_index; // Will update every iteration until last player is loaded
        }
        else
        {
            // cout << "DEBUG Index is now " << curr_index <<endl;

            _all_enemies[curr_index].setName(name);
            _all_enemies[curr_index].setHP(hp);
            _all_enemies[curr_index].setGold(gold);
            _all_enemies[curr_index].setStamina(stamina);
            _all_enemies[curr_index].setDefense(defense);
            _all_enemies[curr_index].setCondition(condition);
            _all_enemies[curr_index].setAdvantage(advantage);
            _all_enemies[curr_index].setItems(items);
            _all_enemies[curr_index].setPotion(0, new_potion);
            _all_enemies[curr_index].setNumPotion(1);
            _all_enemies[curr_index].setEquipment(0, new_equipment);
            _all_enemies[curr_index].setNumEquipment(1);

            _num_enemies = curr_index; // Will uodate every iteration until last enemy is loaded
        }

        /* string second_line;
        Potion potions_array[3];
        split(second_line, ',', )





        _characters[curr_index].setName(name);
        _characters[curr_index].setHP(hp);
        _characters[curr_index].setGold(gold);
        _characters[curr_index].setCondition(condition);
        _characters[curr_index].setIsEnemy(is_enemy);*/
        curr_index++;
    }

    // cout << "We have " << _num_players +1 << " Characters and " << _num_enemies +1 << " Enemies" << endl;

    return true;
}

bool Game::loadItems(string filename)
{
    ifstream in_file(filename);
    if (in_file.fail())
    {
        return false;
    }

    string name;
    string desc;         // Description variable
    char type = 'X';     // D~Weapon S~Sword P~Potion
    char element = 'X';  // W F A E
    double effect_value; // Weapons have damage here and shield have defense here
    double price;

    int num_elements;
    string splitted_line[6];
    int curr_index = 0;
    int equ_index = 0;
    int pot_index = 0;

    string line;            // Input lines from textfile
    getline(in_file, line); // Get rid of first line since it is a title-line

    while (getline(in_file, line))
    {
        num_elements = split(line, '|', splitted_line, 15);

        if (num_elements != 6) // skip invalid rows
        {
            // cout << "DEBUG line " << curr_index << " Has " << num_elements << " and not 6" << endl;
            continue;
        }

        name = splitted_line[0];
        // cout << "DEBUG Gave the name: " << name << " on iteration " << curr_index  << endl;

        desc = splitted_line[1];

        type = splitted_line[2][0];

        if (isDouble(splitted_line[3]))
        {
            effect_value = stod(splitted_line[3]);
        }
        else
        {
            effect_value = 0;
            cout << "effect vlaue set 0 zero since it was not a double" << endl;
        }

        element = splitted_line[4][0];

        if (isDouble(splitted_line[5]))
        {
            price = stod(splitted_line[5]);
        }
        else
        {
            price = 0;
        }

        if (type == 'D') // if weapon
        {

            _all_equipment[equ_index].name = name;
            _all_equipment[equ_index].desc = desc;
            _all_equipment[equ_index].type = type;
            _all_equipment[equ_index].damage = effect_value;
            _all_equipment[equ_index].defense = 0;
            _all_equipment[equ_index].element = element;
            _all_equipment[equ_index].price = price;
            // cout << _all_equipment[equ_index].name << "was successfully iniated" << endl;
            equ_index++;
        }
        else if (type == 'S') // if shield
        {
            _all_equipment[equ_index].name = name;
            _all_equipment[equ_index].desc = desc;
            _all_equipment[equ_index].type = type;
            _all_equipment[equ_index].damage = 0;
            _all_equipment[equ_index].defense = effect_value;
            _all_equipment[equ_index].element = element;
            _all_equipment[equ_index].price = price;
            // cout << _all_equipment[equ_index].name << "was successfully iniated" << endl;
            equ_index++;
        }
        else if (type == 'P') // if potion
        {
            _all_potions[pot_index].name = name;
            _all_potions[pot_index].desc = desc;
            _all_potions[pot_index].type = type;
            _all_potions[pot_index].effect_value = effect_value;
            _all_potions[pot_index].quantity = 0; // default quantity when loading potions
            _all_potions[pot_index].price = price;
            pot_index++;

            // cout << _all_potions[curr_index].name << " was successfully initiated" << endl;
            _num_enemies = curr_index; // Will uodate every iteration until last enemy is loaded
        }
        else
        {
            cout << "Non valid type of weapon. Type: " << type << endl;
        }

        curr_index++;
    }

    return true;
}

Entity Game::playerPick()
{
    bool valid = false;
    string userChoice;
    string player_name;
    cout << "Which character would you like to choose? Enter a number." << endl;
    cout << "(1) Odysseus (2) Argos (3) Circe (4) Achilles" << endl;

    do
    {
        getline(cin, userChoice);
        if (userChoice == "1" || userChoice == "2" || userChoice == "3" || userChoice == "4")
        {
            valid = true;
        }
        else
        {
            cout << "Enter a valid option (1-4)" << endl;
        }

    } while (!valid);

    int num = stoi(userChoice);

    switch (num)
    {
    case 1:
        player_name = "Oddysseus";
        break;
    case 2:
        player_name = "Argos";
        break;
    case 3:
        player_name = "Circe";
        break;
    case 4:
        player_name = "Achilles";
        break;

    default:
        player_name = "";
        break;
    }
    Entity player = getPlayerFromAll(player_name);

    return player;
}

// Returns the current number of players _num_players
int Game::getNumPlayers()
{
    return _num_players;
}

// Returns the current number of enemies _num_enemies
int Game::getNumEnemies()
{
    return _num_enemies;
}

/* Sets the _players array with the provided array of objects.
The number of objects in the array is specified by the int parameter.
If the number of objects is greater than 2, only the first two objects are considered.
The data member _num_players is updated accordingly.*/
void Game::setPlayersList(Entity arr[], int num_players)
{
    if (num_players > 2)
    {
        _num_players = 2;
    }
    else if (num_players < 0)
    {
        _num_players = 0;
    }
    else
    {
        _num_players = num_players;
    }

    for (int i = 0; i < _num_players; i++)
    {
        _players[i] = arr[i];
    }
}

/*Sets the _enemies array with the provided array of objects.
The number of objects in the array is specified by the int parameter.
If the number of objects is greater than 2, only the first two objects are considered.
The data member _num_enemies is updated accordingly.
 */
void Game::setEnemiesList(Entity arr[], int num_enemies)
{

    if (num_enemies > 2)
    {
        _num_enemies = 2;
    }
    else if (num_enemies < 0)
    {
        _num_enemies = 0;
    }
    else
    {
        _num_enemies = num_enemies;
    }
    for (int i = 0; i < _num_enemies; i++)
    {
        _enemies[i] = arr[i];
    }
}

// Replaces a player object at the given index in the _players array. Returns true is successful and false if not
bool Game::setPlayer(int index, Entity new_player)
{
    if (index >= 0 && index <= _num_players)
    {
        _players[index] = new_player;
        return true;
    }
    else
    {
        return false;
    }
}

// Returns an object from the _players array based on the index
Entity Game::getPlayer(int index)
{
    Entity E; // Empty entity

    if (index == 1 || index == 0)
    {
        return _players[index];
    }

    cout << "Didnt find player" << endl;
    return E;
}
// Returns an object from the _all_players array based on the provided name
Entity Game::getPlayerFromAll(string name)
{
    Entity E; // Empty entity
    for (int i = 0; i < _MAX_PLAYERS; i++)
    {
        if (_all_players[i].getName() == name)
        {
            return _all_players[i];
        }
    }
    return E;
}

Potion Game::getPotion(string name)
{
    Potion E; // Empty Potion
    // cout << "Name is: \"" << name << "\" in function" << endl;
    for (int i = 0; i < 10; i++) // Hard coded line
    {
        // cout << "Checking if it is " << _all_potions[i].name << endl;
        if (_all_potions[i].name == name)
        {
            // cout << "Name of potion found " << _all_potions[i].name << endl;
            return _all_potions[i];
        }
    }
    // cout << "Not found" << endl;
    return E;
}
Equipment Game::getEquipment(string name)
{
    Equipment E;
    // cout << "Name is: \"" << name << "\" in function" << endl;
    for (int i = 0; i < 20; i++) // Hard coded line
    {
        // cout << "Checking if it is " << _all_potions[i].name << endl;
        if (_all_equipment[i].name == name)
        {
            // cout << "Name of potion found " << _all_equipment[i].name << endl;
            return _all_equipment[i];
        }
    }
    // cout << "Not found" << endl;
    return E;
}

// Replaces an enemy object at the given index in the _enemies array.
bool Game::setEnemy(int index, Entity new_enemy)
{
    if (index >= 0 && index <= _num_enemies)
    {
        _enemies[index] = new_enemy;
        return true;
    }
    else
    {
        return false;
    }
}

// Returns an object from the _enemies array based on the provided name
// I just return the first one if it is not in the array
Entity Game::getEnemy(string name)
{
    for (int i = 0; i < _num_enemies; i++)
    {
        if (_enemies[i].getName() == name)
        {
            return _enemies[i];
        }
    }

    return _enemies[0];
}

// Returns the index of the player object in the _players array based on the provided name.
int Game::findPlayer(string name)
{
    for (int i = 0; i < _num_players; i++)
    {
        if (_players[i].getName() == name)
        {
            return i;
        }
    }

    return -1;
}

// Finds index of potion with a name
int Game::findPotion(string name)
{
    for (int i = 0; i < _MAX_POTIONS; i++)
    {
        if (name == _all_potions[i].name)
        {
            return i;
        }
    }
    return -1;
}

// Returns the index of the enemy object in the _enemies array based on the provided name.
int Game::findEnemy(string name)
{
    for (int i = 0; i < _num_enemies; i++)
    {
        if (_enemies[i].getName() == name)
        {
            return i;
        }
    }

    return -1;
}

// Prints stats of all the players and enemies that are loaded in
void Game::printAllStats()
{
    cout << "         ALL CHARACTERS " << endl;
    // cout << "DEBUG Iterating players from 0 to " << _num_players << endl;
    for (int i = 0; i < _MAX_PLAYERS; i++)
    {
        // cout << "DEBUG Iteration " << i << "| Player name: " << _all_players[i].getName();
        if (_all_players[i].getName() != "")
        {
            // cout << "DEBUG Trying to print " << _all_players[i].getName() << "'s stats now" << endl;
            _all_players[i].printStats();
            cout << "----------------------------------------------" << endl;
        }
        else
        {
            // cout << "Player not found" << endl;
        }
    }
    // cout << "DEBUG Iterating enemies from 0 to " << _num_enemies << endl;
    cout << "            ALL ENEMIES " << endl;
    for (int i = 0; i < _MAX_ENEMIES; i++)
    {
        // cout << "DEBUG Trying to print " << _all_enemies[i].getName() << "'s stats now" << endl;
        if (_all_enemies[i].getName() != "")
        {
            _all_enemies[i].printStats();
            cout << "----------------------------------------------" << endl;
        }
        else
        {
            // cout << "Enemy not found" << endl;
        }
    }
}

void Game::printAllEquipment()
{
    cout << "         EQUIPMENTS" << endl;
    for (int i = 0; i < _MAX_EQUIPMENT; i++)
    {
        if (_all_equipment[i].name != "")
        {
            cout << "Name:   \t" << _all_equipment[i].name << endl;
            cout << "Description:\t" << _all_equipment[i].desc << endl;
            cout << "Type:   \t" << _all_equipment[i].type << endl;
            cout << "Element:\t" << _all_equipment[i].element << endl;
            cout << "Damage: \t" << _all_equipment[i].damage << endl;
            cout << "Defense:\t" << _all_equipment[i].defense << endl;
            cout << "Price:  \t" << _all_equipment[i].price << endl;
            cout << "--------------------------------------------" << endl;
        }
    }
}

void Game::printAllPotions()
{
    cout << "         POTIONS" << endl;
    for (int i = 0; i < _MAX_POTIONS; i++)
    {
        if (_all_potions[i].name != "")
        {
            cout << "Name:        \t" << _all_potions[i].name << endl;
            cout << "Description: \t" << _all_potions[i].desc << endl;
            cout << "Type:        \t" << _all_potions[i].type << endl;
            cout << "Effect value:\t" << _all_potions[i].effect_value << endl;
            cout << "Price:       \t" << _all_potions[i].price << endl;
            cout << "Quantity:    \t" << _all_potions[i].quantity << endl;
            cout << "--------------------------------------------" << endl;
        }
    }
}

// Prints options, MOve, Swap/Drop, Potion,stats or quir. returns valid option 1-5
int Game::mainMenu()
{
    cout << "1. Move " << endl;
    cout << "2. Swap / Drop Weapon" << endl;
    cout << "3. Use Potion" << endl;
    cout << "4. Print Player Stats" << endl;
    cout << "5. Quit" << endl;

    string pick;
    while (pick != "1" && pick != "2" && pick != "3" && pick != "4" && pick != "5")
    {
        cout << "please choose a valid input (1-5) " << endl;
        getline(cin, pick);
    }
    int option = stoi(pick);
    return option;
}