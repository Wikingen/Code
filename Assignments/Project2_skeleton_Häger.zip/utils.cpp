#include <stdio.h>
#include <stdlib.h>
using namespace std;


//returns an int 1-6 incluseive
int diceRoll()
{
    int rand_num = rand() % 6 + 1;
    return rand_num;
}