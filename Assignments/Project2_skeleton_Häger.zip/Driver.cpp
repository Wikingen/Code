#include "Entity.hpp"
#include "Game.hpp"
#include "Map.hpp"
#include "Items.hpp"
#include "utils.hpp"


#define RED "\033[41m"     /* Red */
#define GREEN "\033[42m"   /* Green */
#define BLUE "\033[44m"    /* Blue */
#define MAGENTA "\033[45m" /* Magenta */
#define CYAN "\033[46m"    /* Cyan */
#define RESET "\033[0m"

#include <ctype.h>

using namespace std;


// The point of this file is to demonstrate what you could make to help test different parts of your code
// without necessarily having all parts implemented.

// Ideally you test and work on the individual parts and add them in piece-by-piece, until you have the whole thing to place into its own driver file.

int main()
{
    string filename;

    // initialize
    Game m_game;

    //Load Items
    filename = "items.txt";
    m_game.loadItems(filename);
    cout << "Items Loaded" << endl;
    
    //Load in txt files
    filename = "characters.txt";
    m_game.loadEnteties(filename, true);

    filename = "enemies.txt";
    m_game.loadEnteties(filename, false);
    cout << "Entities Loaded" << endl;

    /* initialize random seed: */
    srand(time(NULL));

    Map m_map = Map();
    // initialize tiles
    m_map.initializeMap();
    cout << "Map initialized" << endl;
    //initiate positions to 0 
    m_map.setPlayerPos(0, 0);
    m_map.setPlayerPos(1, 0);

    

    

    

    // get player 1
    Entity player1 = m_game.playerPick();
    cout << "Player 1 has chosen " << player1.getName() << "!" << endl;
    
    Entity player2 = m_game.playerPick();
    cout << "Player 2 has chosen " << player2.getName() << "!" << endl;


    cout << "Here is our map:" << endl;
    m_map.printMap();
    
    //Randomizes which player starts
    int current_player = rand() % 2;
    cout << "After a dice roll it is set that player" << current_player << "starts" << endl;

    //Int that tracks player who won, -1 is default
    int player_won = -1; 

    //while noone has reached Ithaca
    while (m_map.getPlayerPos(0) < 50 && m_map.getPlayerPos(1) < 50) 
    {
        
        int option = m_game.mainMenu();
        if(option == 1)
        {
            //Updates postion
            int steps = diceRoll();
            cout << "You rolled a " << steps << endl;
            m_map.movePlayer(0,steps);
            m_map.printMap();
        }
        else if(option == 5)
        {
            //Game is quitted and player_won is not set. 
            break;
        }
        else
        {
            cout << "We have unfortunately not implemented this feature yet" << endl;
        }

        string color = m_map.getTileColor(0);

        cout << "You landed on " << color << " Which is postion " << RESET << endl;
    }



    //Game over, check if anyone won
    if (player_won != -1)
    {
            cout << m_game.getPlayer(player_won).getName() << " has won!!!!" << endl;
    }
    else
    {
        cout << "Game has been quitted. Thanks for playing" << endl;
    }

    /* 
    // Combat testing
    // let's say I haven't figured out how to connect things to the game's list of entities yet, but I want to get my combat function out of the way
    // I can still work on creating the general idea of my combat function and worry about putting it into everything later

    // here I am just manually creating some players to test with
    Entity player = Entity("Argos", 120.0, 100.0, 20.0, 'H', false, 'W', 50, false);
    Entity enemy = Entity("Sirens", 150.0, 100.0, 25.0, 'H', false, 'E', 25, true);

    // manually providing Equipment to each one
    // NOTE: your setEquipment should have more parameters than mine does
    player.setEquipment("Bow of Odysseus", 'W', 10.0);
    enemy.setEquipment("Lotus Staff", 'E', 10.0);

    // calling my combat function to test - output is in the GitHub under Combat
    m_game.combat(player, enemy);

     */

    return 0;
}