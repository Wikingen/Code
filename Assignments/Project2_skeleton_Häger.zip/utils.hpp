#ifndef UTILS_H
#define UTILS_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Utils.hpp will include all non class functions that serves the purpose of cleaning up the main driver */


// returns an int 1-6 incluseive
int diceRoll();


#endif